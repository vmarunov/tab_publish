# -*- coding: utf-8 -*-
from tableaudocumentapi import Workbook


def create():
    src = Workbook('!.twb')
    src.save_as()


if __name__ == '__main__':
    create()
