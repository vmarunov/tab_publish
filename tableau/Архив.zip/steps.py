# -*- coding: utf-8 -*-
from redis import StrictRedis as R

DATA = [
    ("2001-01-01", "ALL", 1000, "ALL", "USA", 0),
    ("2001-01-01", "Microsoft", 100, "Software", "USA", 1),
    ("2001-01-01", "ALL", 400, "Software", "USA", 1),
    ("2001-01-01", "Microsoft", 100, "Software", "USA", 2),
    ("2001-01-01", "Other", 300, "Software", "USA", 2),
    ("2001-01-01", "Other", 100, "Other", "USA", 2),
    ("2001-01-01", "Other", 600, "Oil", "USA", 2),
    ("2001-01-01", "Oracle", 100, "Software", "USA", 2),
    ("2001-01-01", "Other", 400, "Software", "USA", 2),
    ("2001-01-01", "Other", 1500, "Other", "Other", 2),
    ("2001-01-01", "Other", 600, "Oil", "USA", 2),
    ("2001-01-01", "Other", 800, "Other", "China", 2),
    ("2001-02-01", "Microsoft", 100, "Software", "USA", 2),
    ("2001-02-01", "Other", 300, "Software", "USA", 2),
    ("2001-02-01", "Other", 100, "Other", "USA", 2),
    ("2001-02-01", "Other", 600, "Oil", "USA", 2),
    ("2001-02-01", "Oracle", 100, "Software", "USA", 2),
    ("2001-02-01", "Other", 400, "Software", "USA", 2),
    ("2001-02-01", "Other", 1500, "Other", "Other", 2),
    ("2001-02-01", "Other", 600, "Oil", "USA", 2),
    ("2001-02-01", "Other", 800, "Other", "China", 2),
]

REDIS = R(password='qqq')


if __name__ == '__main__':
    cnt = 0
    keys = ['date', 'company', 'profit', 'profit_industry', 'country', 'step']
    for row in DATA:
        key = 'economic:{}'.format(cnt)
        REDIS.hmset(key, dict(zip(keys, row)))
        cnt += 1
