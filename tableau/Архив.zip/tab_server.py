# -*- coding: utf-8 -*-
from flask import Flask, jsonify, request

from tableaudocumentapi import Workbook
import tableauserverclient as TSC

app = Flask(__name__)


@app.route('/api/export_tableau', methods=['POST'])
def export():
    data = request.get_json()
    return jsonify(data)


def test():
    wb = Workbook('template.twbx')
    print(wb)


def test_login():
    tableau_auth = TSC.TableauAuth('volodya.marunov@skybonds.com', ',ehueylbz47', site='vladimir.marunov')
    server = TSC.Server('https://public.tableau.com/profile/vladimir.marunov')
    with server.auth.sign_in(tableau_auth):
        all_datasources, pagination_item = server.datasources.get()
        print("\nThere are {} datasources on site: ".format(
            pagination_item.total_available))
        print([datasource.name for datasource in all_datasources])


if __name__ == '__main__':
    # app.run()
    test_login()
